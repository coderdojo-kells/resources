guizero is designed to be used by children. In educational settings,
installation of extra programs and features may be difficult, so the set up
process is designed to be as simple as possible.

